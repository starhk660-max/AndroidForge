package com.uchiha.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var titleView: TextView
    private val webViews = mutableListOf<WebView>()
    private var activeIndex = 0
    private val prefs by lazy { getSharedPreferences("uchiha_browser", Context.MODE_PRIVATE) }
    private val bookmarks = mutableListOf<String>()
    private val history = mutableListOf<String>()

    private val activeWebView: WebView?
        get() = webViews.getOrNull(activeIndex)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadLists()
        buildUi()
        addTab("https://www.google.com")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101014.toInt())
        }

        val brand = TextView(this).apply {
            text = "◉  UCHIHA BROWSER"
            textSize = 18f
            setTextColor(0xFFFF5252.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 12, 16, 8)
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, -2))

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
        }
        address = EditText(this).apply {
            hint = "Search or enter website"
            singleLine = true
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            setPadding(12, 0, 12, 0)
            setBackgroundColor(0xFF25252D.toInt())
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, 46, 1f))
        val go = button("GO") { loadFromAddress() }
        addressRow.addView(go, LinearLayout.LayoutParams(56, 46))
        root.addView(addressRow)

        address.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == android.view.KeyEvent.KEYCODE_ENTER)) {
                loadFromAddress()
                true
            } else false
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 3))

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        toolbar.addView(button("‹") { if (activeWebView?.canGoBack() == true) activeWebView?.goBack() else toast("No previous page") }, weightParams())
        toolbar.addView(button("›") { if (activeWebView?.canGoForward() == true) activeWebView?.goForward() else toast("No next page") }, weightParams())
        toolbar.addView(button("↻") { activeWebView?.reload() }, weightParams())
        toolbar.addView(button("⌂") { activeWebView?.loadUrl("https://www.google.com") }, weightParams())
        toolbar.addView(button("★") { saveBookmark() }, weightParams())
        toolbar.addView(button("Tabs") { showTabs() }, weightParams())
        root.addView(toolbar, LinearLayout.LayoutParams(-1, 48))

        titleView = TextView(this).apply {
            text = "Ready"
            textSize = 11f
            setTextColor(0xFFBBBBBB.toInt())
            setPadding(12, 2, 12, 4)
            maxLines = 1
        }
        root.addView(titleView, LinearLayout.LayoutParams(-1, -2))

        val historyButton = button("History") { showSavedList("History", history) }
        val bookmarksButton = button("Bookmarks") { showSavedList("Bookmarks", bookmarks) }
        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(historyButton, weightParams())
            addView(bookmarksButton, weightParams())
        }
        root.addView(quickRow, LinearLayout.LayoutParams(-1, 40))
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF292932.toInt())
            setOnClickListener { action() }
        }

    private fun weightParams() = LinearLayout.LayoutParams(0, -1, 1f)

    private fun addTab(url: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE
                progress.progress = 5
                address.setText(url ?: "")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                address.setText(url ?: "")
                titleView.text = view?.title ?: url ?: "Page loaded"
                if (!url.isNullOrBlank() && !url.startsWith("about:")) {
                    if (history.firstOrNull() != url) history.add(0, url)
                    if (history.size > 200) history.removeAt(history.lastIndex)
                    saveLists()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }
        web.setDownloadListener(DownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(downloadUrl))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(android.webkit.URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType))
                    .setDescription("Downloading with Uchiha Browser")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        android.webkit.URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                toast("Download started")
            } catch (e: Exception) {
                toast("Couldn't start download")
            }
        })
        webViews.add(web)
        activeIndex = webViews.lastIndex
        web.loadUrl(url)
        showActiveWebView()
        updateTabsLabel()
    }

    private fun showActiveWebView() {
        // Keep browser controls at the top; WebView occupies remaining space.
        for (wv in webViews) {
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
        }
        activeWebView?.let { web ->
            root.addView(web, root.indexOfChild(titleView) + 1,
                LinearLayout.LayoutParams(-1, 0, 1f))
            web.visibility = View.VISIBLE
        }
    }

    private fun loadFromAddress() {
        val raw = address.text.toString().trim()
        if (raw.isEmpty()) return
        val url = when {
            raw.startsWith("https://", true) || raw.startsWith("http://", true) -> raw
            raw.contains(".") && !raw.contains(" ") -> "https://$raw"
            else -> "https://www.google.com/search?q=" + Uri.encode(raw)
        }
        activeWebView?.loadUrl(url) ?: addTab(url)
    }

    private fun saveBookmark() {
        val url = activeWebView?.url
        if (url.isNullOrBlank()) return
        if (!bookmarks.contains(url)) bookmarks.add(0, url)
        saveLists()
        toast("Bookmark saved")
    }

    private fun showSavedList(title: String, items: List<String>) {
        if (items.isEmpty()) {
            toast("No $title yet")
            return
        }
        val choices = items.take(100).toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(choices) { _, which -> activeWebView?.loadUrl(choices[which]) }
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showTabs() {
        if (webViews.isEmpty()) {
            addTab("https://www.google.com")
            return
        }
        val labels = webViews.mapIndexed { index, web ->
            "${if (index == activeIndex) "● " else ""}${web.title ?: web.url ?: "New tab"}"
        }.toMutableList()
        labels.add("＋ New tab")
        android.app.AlertDialog.Builder(this)
            .setTitle("Tabs (${webViews.size})")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == webViews.size) addTab("https://www.google.com")
                else {
                    activeIndex = which
                    showActiveWebView()
                    address.setText(activeWebView?.url ?: "")
                    updateTabsLabel()
                }
            }
            .setNeutralButton("Close active tab") { _, _ -> closeActiveTab() }
            .setPositiveButton("Done", null)
            .show()
    }

    private fun closeActiveTab() {
        if (webViews.isEmpty()) return
        val removed = webViews.removeAt(activeIndex)
        removed.stopLoading()
        removed.destroy()
        if (webViews.isEmpty()) {
            addTab("https://www.google.com")
        } else {
            activeIndex = activeIndex.coerceAtMost(webViews.lastIndex)
            showActiveWebView()
            address.setText(activeWebView?.url ?: "")
            updateTabsLabel()
        }
    }

    private fun updateTabsLabel() {
        titleView.text = "${activeWebView?.title ?: "Uchiha Browser"}  •  Tab ${activeIndex + 1}/${webViews.size}"
    }

    private fun loadLists() {
        try {
            val b = JSONArray(prefs.getString("bookmarks", "[]"))
            for (i in 0 until b.length()) bookmarks.add(b.getString(i))
            val h = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until h.length()) history.add(h.getString(i))
        } catch (_: Exception) {}
    }

    private fun saveLists() {
        prefs.edit()
            .putString("bookmarks", JSONArray(bookmarks).toString())
            .putString("history", JSONArray(history).toString())
            .apply()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (activeWebView?.canGoBack() == true) activeWebView?.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        webViews.forEach {
            it.stopLoading()
            it.destroy()
        }
        webViews.clear()
        super.onDestroy()
    }
}
