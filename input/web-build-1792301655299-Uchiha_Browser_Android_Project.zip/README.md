# Uchiha Browser (Android)

A starter Android browser project built with Kotlin and Android WebView. It includes:
- Google search / URL address bar
- Back, forward, reload, home
- Tab management (simple in-memory tabs)
- Bookmarks (stored locally)
- Browsing history (stored locally)
- Dark-themed interface
- Basic download support through Android DownloadManager

## Build on Android phone
This is a standard Android Gradle project. You can try opening it in AndroidIDE on your phone:
1. Install AndroidIDE from its official project page: https://github.com/AndroidIDEOfficial/AndroidIDE
2. Extract this ZIP.
3. Open/import the extracted project folder in AndroidIDE.
4. Allow Gradle sync and install any requested Android SDK/build tools.
5. Build and run the `app` configuration.

Mobile builds may require a lot of free storage and RAM. If AndroidIDE cannot sync the current Gradle/Android plugin versions, update the app's Gradle plugin version and wrapper to versions supported by your installed AndroidIDE.

## Notes
- Package: `com.uchiha.browser`
- App label: `Uchiha Browser`
- This is a starter project, not a full Chromium/Brave replacement.
- WebView uses the Android system WebView/Chrome engine.
- Incognito/private mode is not implemented in this basic version.
- Bookmark and history storage is local to the app.
